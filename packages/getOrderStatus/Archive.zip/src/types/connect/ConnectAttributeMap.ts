export interface AttributeMap {
    [key: string]: string;
  }