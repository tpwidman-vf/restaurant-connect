export interface Endpoint {
    Address: string; // +12025551234
    Type: string; // TELEPHONE_NUMBER
  }